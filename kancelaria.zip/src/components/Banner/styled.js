import styled from "styled-components";


export const BannerBlock = styled.div`
.gatsby-image-wrapper{
    width:100%;
}
img{object-fit: inherit !important;}
`