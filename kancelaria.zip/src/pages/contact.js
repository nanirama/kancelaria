import * as React from "react"

import Layout from "../components/Layout"
import Banner from "../components/Banner"
import Contact from "../components/Contact"

const Contactpage = () => {
    return (
<>
<Layout>
<Banner/>
<Contact/>
</Layout>
</>

    );
};
export default Contactpage;